package com.anichin.claimhelper

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log sederhana ke file + callback ke UI. Dipakai dari main thread saja. */
object ClaimLog {
    private var file: File? = null
    var onChange: (() -> Unit)? = null
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss.SSS", Locale.US)

    fun init(ctx: Context) {
        if (file == null) {
            file = File(ctx.applicationContext.filesDir, "claim_log.txt")
            try {
                val f = file!!
                if (f.exists() && f.length() > 200_000) {
                    val tail = f.readLines().takeLast(200).joinToString("\n") + "\n"
                    f.writeText(tail)
                }
            } catch (_: Exception) {
            }
        }
    }

    fun add(msg: String) {
        val line = "${fmt.format(Date())}  $msg"
        Log.i("ClaimHelper", line)
        try {
            file?.appendText(line + "\n")
        } catch (_: Exception) {
        }
        onChange?.invoke()
    }

    fun read(): String = try {
        file?.takeIf { it.exists() }?.readLines()?.takeLast(200)?.joinToString("\n") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun clear() {
        try {
            file?.writeText("")
        } catch (_: Exception) {
        }
        onChange?.invoke()
    }
}
