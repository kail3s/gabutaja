package com.anichin.claimhelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

const val TARGET_PKG = "com.anichin.donghub"

class ClaimService : AccessibilityService() {

    private enum class State { IDLE, ARMED, WAIT_RESULT, DONE }

    companion object {
        // ====== SESUAIKAN JIKA TEKS DI DONGHIVE BERBEDA ======
        const val COUNTDOWN_TEXT = "Bisa diklaim"   // "Bisa diklaim dalam waktu ..."
        const val CLAIM_TEXT = "CLAIM"
        const val SLOT_TEXT = "Slot habis"

        // Teks konfirmasi dari aplikasi/server (huruf besar-kecil diabaikan).
        // Sukses HANYA dicatat jika salah satu teks ini muncul SETELAH klik.
        val OK_WORDS = listOf("berhasil", "success", "selamat")
        val FAIL_WORDS = listOf(
            "gagal", "failed", "error", "tidak berhasil",
            "sudah pernah", "sudah diklaim", "already", "tidak dapat"
        )
        const val RESULT_TIMEOUT_MS = 8_000L
    }

    private var state = State.IDLE
    private var armedClaimBaseline = 0
    private var clickAt = 0L
    private var baseSlot = 0
    private var baseWords: Map<String, Int> = emptyMap()
    private val handler = Handler(Looper.getMainLooper())

    private val timeoutTask = Runnable {
        if (state == State.WAIT_RESULT) {
            finish("TIDAK TERKONFIRMASI - tidak ada teks sukses/gagal/slot habis terbaca dalam ${RESULT_TIMEOUT_MS / 1000} dtk (klaim BELUM bisa dianggap berhasil)")
        }
    }

    override fun onServiceConnected() {
        ClaimLog.init(this)
        state = State.IDLE
        ClaimLog.add("Service aktif, memantau $TARGET_PKG. Klik otomatis: ${if (Prefs.autoClick(this)) "ON" else "OFF"}")
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ClaimLog.add("Service dimatikan")
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.packageName?.toString() != TARGET_PKG) return

        // Toast / notifikasi dari Donghive -> bisa jadi konfirmasi server
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            if (state == State.WAIT_RESULT) {
                classifyText(event.text.joinToString(" "))?.let { finish(it) }
            }
            return
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != TARGET_PKG) return

        when (state) {
            State.IDLE, State.DONE -> {
                if (hasText(root, COUNTDOWN_TEXT)) {
                    armedClaimBaseline = findClaims(root).size
                    state = State.ARMED
                    ClaimLog.add("Countdown giveaway terdeteksi -> menunggu berubah jadi CLAIM")
                } else if (state == State.IDLE && Prefs.clickExisting(this)) {
                    val claims = findClaims(root)
                    if (claims.isNotEmpty()) attemptClick(claims, event.eventTime)
                }
            }
            State.ARMED -> {
                val claims = findClaims(root)
                if (claims.size < armedClaimBaseline) armedClaimBaseline = claims.size
                if (claims.size > armedClaimBaseline) attemptClick(claims, event.eventTime)
            }
            State.WAIT_RESULT -> evaluate(root)
        }
    }

    // ---------- klik (maksimal 1x per giveaway) ----------

    private fun attemptClick(claims: List<AccessibilityNodeInfo>, eventTime: Long) {
        val node = claims.maxByOrNull { bottomOf(it) } ?: return
        if (!Prefs.autoClick(this)) {
            ClaimLog.add("CLAIM terdeteksi, tapi klik otomatis OFF -> tidak diklik")
            state = State.DONE
            return
        }
        val ok = clickNode(node)
        clickAt = SystemClock.elapsedRealtime()
        val delay = SystemClock.uptimeMillis() - eventTime
        if (!ok) {
            ClaimLog.add("CLAIM terdeteksi tapi klik tidak bisa dieksekusi (1 percobaan, tidak diulang)")
            state = State.DONE
            return
        }
        // baseline teks di layar supaya teks lama (chat sebelumnya) tidak dianggap hasil
        val root = rootInActiveWindow
        if (root != null) {
            baseSlot = count(root, SLOT_TEXT)
            baseWords = (OK_WORDS + FAIL_WORDS).associateWith { count(root, it) }
        } else {
            baseSlot = 0
            baseWords = emptyMap()
        }
        state = State.WAIT_RESULT
        ClaimLog.add("CLAIM diklik 1x (${delay} ms sejak event). Menunggu konfirmasi server...")
        handler.postDelayed(timeoutTask, RESULT_TIMEOUT_MS)
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.isEnabled && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            n = n.parent
            depth++
        }
        // Cadangan: satu ketukan di tengah elemen
        val r = Rect()
        node.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    // ---------- membaca hasil ----------

    private fun evaluate(root: AccessibilityNodeInfo) {
        if (count(root, SLOT_TEXT) > baseSlot) {
            finish("GAGAL - Slot habis (status terbaca dari aplikasi)")
            return
        }
        FAIL_WORDS.firstOrNull { count(root, it) > (baseWords[it] ?: 0) }?.let {
            finish("GAGAL - aplikasi menampilkan teks \"$it\"")
            return
        }
        OK_WORDS.firstOrNull { count(root, it) > (baseWords[it] ?: 0) }?.let {
            finish("BERHASIL - aplikasi menampilkan konfirmasi \"$it\"")
        }
    }

    private fun classifyText(raw: String): String? {
        val s = raw.lowercase()
        if (s.contains(SLOT_TEXT.lowercase())) return "GAGAL - Slot habis (toast: $raw)"
        FAIL_WORDS.firstOrNull { s.contains(it) }?.let { return "GAGAL - toast: $raw" }
        OK_WORDS.firstOrNull { s.contains(it) }?.let { return "BERHASIL - toast: $raw" }
        return null
    }

    private fun finish(msg: String) {
        handler.removeCallbacks(timeoutTask)
        state = State.DONE
        val took = SystemClock.elapsedRealtime() - clickAt
        ClaimLog.add("$msg [${took} ms setelah klik]")
    }

    // ---------- util ----------

    private fun count(root: AccessibilityNodeInfo, text: String) =
        root.findAccessibilityNodeInfosByText(text).size

    private fun hasText(root: AccessibilityNodeInfo, text: String) =
        root.findAccessibilityNodeInfosByText(text).isNotEmpty()

    /** Elemen yang teksnya tepat "CLAIM" (bukan kata claim di dalam chat orang lain). */
    private fun findClaims(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> =
        root.findAccessibilityNodeInfosByText(CLAIM_TEXT).filter {
            it.isVisibleToUser && (
                it.text?.toString()?.trim().equals(CLAIM_TEXT, ignoreCase = true) ||
                it.contentDescription?.toString()?.trim().equals(CLAIM_TEXT, ignoreCase = true)
                )
        }

    private fun bottomOf(n: AccessibilityNodeInfo): Int {
        val r = Rect()
        n.getBoundsInScreen(r)
        return r.bottom
    }
}
