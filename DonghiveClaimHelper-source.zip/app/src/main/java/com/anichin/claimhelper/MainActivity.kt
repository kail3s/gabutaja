package com.anichin.claimhelper

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClaimLog.init(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, insets ->
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            v.setPadding(pad + b.left, pad + b.top, pad + b.right, pad + b.bottom)
            insets
        }

        status = TextView(this).apply { textSize = 16f; setTypeface(typeface, Typeface.BOLD) }
        root.addView(status)

        root.addView(button("Buka pengaturan Aksesibilitas") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val swAuto = Switch(this).apply {
            text = "Klik otomatis CLAIM (maks. 1x per giveaway)"
            isChecked = Prefs.autoClick(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setAutoClick(this@MainActivity, c) }
        }
        root.addView(swAuto)

        val swExisting = Switch(this).apply {
            text = "Klik juga CLAIM yang sudah tampil tanpa countdown"
            isChecked = Prefs.clickExisting(this@MainActivity)
            setOnCheckedChangeListener { _, c -> Prefs.setClickExisting(this@MainActivity, c) }
        }
        root.addView(swExisting)

        root.addView(button("Buka Donghive") {
            val i = packageManager.getLaunchIntentForPackage(TARGET_PKG)
            if (i != null) startActivity(i)
            else Toast.makeText(this, "Donghive ($TARGET_PKG) tidak terpasang", Toast.LENGTH_LONG).show()
        })
        root.addView(button("Hapus log") { ClaimLog.clear() })

        logView = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        scroll = ScrollView(this).apply { addView(logView) }
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        refreshLog()
        ClaimLog.onChange = { runOnUiThread { refreshLog() } }
    }

    override fun onPause() {
        ClaimLog.onChange = null
        super.onPause()
    }

    private fun button(label: String, onClick: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { onClick() } }

    private fun refreshStatus() {
        val on = serviceOn()
        status.text = if (on) "Service: AKTIF (memantau Donghive)" else "Service: MATI - aktifkan di Aksesibilitas"
        status.setTextColor(if (on) 0xFF1B8A3B.toInt() else 0xFFC62828.toInt())
    }

    private fun refreshLog() {
        logView.text = ClaimLog.read().ifEmpty { "(log kosong)" }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun serviceOn(): Boolean {
        val am = getSystemService(AccessibilityManager::class.java)
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == ClaimService::class.java.name
        }
    }
}
