package com.anichin.claimhelper

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Master switch klik otomatis. Default OFF supaya aman. */
    fun autoClick(c: Context) = sp(c).getBoolean("auto", false)
    fun setAutoClick(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto", v).apply()

    /** Jika ON: CLAIM yang sudah tampil tanpa melihat countdown dulu juga diklik (1x). */
    fun clickExisting(c: Context) = sp(c).getBoolean("existing", false)
    fun setClickExisting(c: Context, v: Boolean) = sp(c).edit().putBoolean("existing", v).apply()
}
